# Game Integrity Checker (C++)

A small defensive cybersecurity project that demonstrates file-integrity checking for a game directory using SHA-256 hashes.

## Features

- Creates a baseline manifest of file hashes.
- Compares files against a previously created baseline.
- Reports changed and missing files.
- Uses OpenSSL's EVP API for SHA-256.
- Uses C++17 filesystem utilities.

## Requirements

- A C++17 compiler
- CMake 3.16+
- OpenSSL development libraries

## Build

```bash
cmake -S . -B build
cmake --build build --config Release
```

The executable is usually created in `build/` (or `build/Release/` on some Windows generators).

## Usage

Create a baseline from a trusted game directory:

```bash
game-integrity-checker baseline "/path/to/game" "trusted-baseline.txt"
```

Check the directory later:

```bash
game-integrity-checker check "/path/to/game" "trusted-baseline.txt"
```

On Windows, use quoted paths, for example:

```powershell
.\build\Release\game-integrity-checker.exe baseline "C:\Games\Example" "C:\Security\trusted-baseline.txt"
.\build\Release\game-integrity-checker.exe check "C:\Games\Example" "C:\Security\trusted-baseline.txt"
```

## Security notes

- Create the baseline only from files you trust.
- Store the baseline outside the game directory and protect it from modification.
- A changed hash indicates a difference, not necessarily malicious activity.
- This first version checks files listed in the baseline; it does not report newly added files.
- This is a learning project, not a production anti-cheat or malware-detection system.
- Avoid running it with elevated privileges unless you have a specific reason.

## CV wording (use after you have built and tested it)

**Game Integrity Checker — C++ (Personal Project)**
- Developed a C++17 command-line utility to create and verify SHA-256 baselines for game files.
- Implemented reporting for modified and missing files using filesystem traversal and hash comparison.
- Used OpenSSL EVP APIs and CMake to build a cross-platform-oriented command-line project.

Only describe this as completed on your CV after you have successfully built and tested it.
