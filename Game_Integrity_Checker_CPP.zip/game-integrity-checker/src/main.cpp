#include <openssl/evp.h>

#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <vector>

namespace fs = std::filesystem;

std::string sha256_file(const fs::path& file_path) {
    std::ifstream file(file_path, std::ios::binary);
    if (!file) {
        throw std::runtime_error("Cannot open file: " + file_path.string());
    }

    EVP_MD_CTX* context = EVP_MD_CTX_new();
    if (context == nullptr) {
        throw std::runtime_error("Could not create SHA-256 context.");
    }

    if (EVP_DigestInit_ex(context, EVP_sha256(), nullptr) != 1) {
        EVP_MD_CTX_free(context);
        throw std::runtime_error("Could not initialize SHA-256.");
    }

    std::vector<char> buffer(64 * 1024);
    while (file) {
        file.read(buffer.data(), static_cast<std::streamsize>(buffer.size()));
        const std::streamsize count = file.gcount();
        if (count > 0 &&
            EVP_DigestUpdate(context, buffer.data(),
                             static_cast<std::size_t>(count)) != 1) {
            EVP_MD_CTX_free(context);
            throw std::runtime_error("Could not update SHA-256.");
        }
    }

    unsigned char digest[EVP_MAX_MD_SIZE];
    unsigned int digest_length = 0;
    const int result = EVP_DigestFinal_ex(context, digest, &digest_length);
    EVP_MD_CTX_free(context);

    if (result != 1) {
        throw std::runtime_error("Could not finalize SHA-256.");
    }

    static const char hex[] = "0123456789abcdef";
    std::string output;
    output.reserve(digest_length * 2);
    for (unsigned int i = 0; i < digest_length; ++i) {
        output.push_back(hex[digest[i] >> 4]);
        output.push_back(hex[digest[i] & 0x0f]);
    }
    return output;
}

bool is_within_directory(const fs::path& root, const fs::path& candidate) {
    auto root_it = root.begin();
    auto candidate_it = candidate.begin();

    for (; root_it != root.end(); ++root_it, ++candidate_it) {
        if (candidate_it == candidate.end() || *root_it != *candidate_it) {
            return false;
        }
    }
    return true;
}

std::map<std::string, std::string> load_manifest(const fs::path& manifest_path) {
    std::ifstream input(manifest_path);
    if (!input) {
        throw std::runtime_error("Cannot open manifest: " + manifest_path.string());
    }

    std::map<std::string, std::string> entries;
    std::string line;
    std::size_t line_number = 0;

    while (std::getline(input, line)) {
        ++line_number;
        if (line.empty() || line[0] == '#') {
            continue;
        }

        const auto separator = line.find('\t');
        if (separator == std::string::npos) {
            throw std::runtime_error("Invalid manifest format on line " +
                                     std::to_string(line_number));
        }

        const std::string hash = line.substr(0, separator);
        const std::string relative_path = line.substr(separator + 1);
        if (hash.size() != 64 || relative_path.empty()) {
            throw std::runtime_error("Invalid manifest entry on line " +
                                     std::to_string(line_number));
        }
        entries[relative_path] = hash;
    }
    return entries;
}

void create_baseline(const fs::path& directory, const fs::path& manifest_path) {
    if (!fs::is_directory(directory)) {
        throw std::runtime_error("Target path is not a directory: " + directory.string());
    }

    const fs::path root = fs::canonical(directory);
    std::ofstream output(manifest_path);
    if (!output) {
        throw std::runtime_error("Cannot write manifest: " + manifest_path.string());
    }

    output << "# Game Integrity Checker baseline: SHA-256<TAB>relative-path\n";
    std::size_t count = 0;

    for (const auto& item : fs::recursive_directory_iterator(
             root, fs::directory_options::skip_permission_denied)) {
        if (!item.is_regular_file()) {
            continue;
        }

        const fs::path absolute_file = fs::canonical(item.path());
        if (!is_within_directory(root, absolute_file)) {
            std::cerr << "[SKIP] File resolves outside target directory: "
                      << item.path().string() << '\n';
            continue;
        }

        const std::string relative = fs::relative(absolute_file, root).generic_string();
        if (relative.find('\t') != std::string::npos ||
            relative.find('\n') != std::string::npos) {
            std::cerr << "[SKIP] Unsupported filename: " << relative << '\n';
            continue;
        }

        output << sha256_file(absolute_file) << '\t' << relative << '\n';
        ++count;
    }

    std::cout << "Baseline created: " << manifest_path
              << "\nFiles recorded: " << count << '\n';
    std::cout << "Keep this manifest somewhere trusted and outside the game directory.\n";
}

void verify_directory(const fs::path& directory, const fs::path& manifest_path) {
    if (!fs::is_directory(directory)) {
        throw std::runtime_error("Target path is not a directory: " + directory.string());
    }

    const fs::path root = fs::canonical(directory);
    const auto expected = load_manifest(manifest_path);
    std::size_t changed = 0;
    std::size_t missing = 0;
    std::size_t checked = 0;

    for (const auto& [relative, expected_hash] : expected) {
        const fs::path candidate = root / fs::path(relative);

        if (!fs::exists(candidate) || !fs::is_regular_file(candidate)) {
            std::cout << "[MISSING] " << relative << '\n';
            ++missing;
            continue;
        }

        const fs::path resolved = fs::canonical(candidate);
        if (!is_within_directory(root, resolved)) {
            std::cout << "[UNSAFE PATH] " << relative << '\n';
            ++changed;
            continue;
        }

        const std::string actual_hash = sha256_file(resolved);
        ++checked;
        if (actual_hash != expected_hash) {
            std::cout << "[CHANGED] " << relative << '\n';
            ++changed;
        } else {
            std::cout << "[OK] " << relative << '\n';
        }
    }

    std::cout << "\nVerification summary\n"
              << "Files checked: " << checked << '\n'
              << "Changed or unsafe: " << changed << '\n'
              << "Missing: " << missing << '\n';

    if (changed == 0 && missing == 0) {
        std::cout << "No changes detected in files listed in the baseline.\n";
    } else {
        std::cout << "Differences found. Review them before taking action.\n";
    }
    std::cout << "Note: this tool does not detect new files absent from the baseline.\n";
}

void print_usage(const char* program) {
    std::cout
        << "Game Integrity Checker - SHA-256 file integrity demo\n\n"
        << "Usage:\n"
        << "  " << program << " baseline <game-directory> <manifest-file>\n"
        << "  " << program << " check    <game-directory> <manifest-file>\n\n"
        << "Create a baseline from trusted files, then verify them later.\n";
}

int main(int argc, char* argv[]) {
    if (argc != 4) {
        print_usage(argv[0]);
        return 2;
    }

    try {
        const std::string command = argv[1];
        const fs::path directory = argv[2];
        const fs::path manifest = argv[3];

        if (command == "baseline") {
            create_baseline(directory, manifest);
        } else if (command == "check") {
            verify_directory(directory, manifest);
        } else {
            print_usage(argv[0]);
            return 2;
        }
    } catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }

    return 0;
}
